package com.example.bolt.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.bolt.data.model.Album

@Dao
interface AlbumDao {
    @Insert
    suspend fun insert(album: Album)

    @Query("SELECT * FROM albums ORDER BY timestamp DESC")
    suspend fun getAllAlbums(): List<Album>
}
