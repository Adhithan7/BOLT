package com.example.bolt.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bolt.R
import com.example.bolt.data.dao.AlbumDao
import com.example.bolt.data.database.AppDatabase
import com.example.bolt.adapter.AlbumAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AlbumActivity : AppCompatActivity() {

    private lateinit var albumDao: AlbumDao
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AlbumAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_album)

        albumDao = AppDatabase.getInstance(this).albumDao()

        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AlbumAdapter()
        recyclerView.adapter = adapter

        loadAlbums()
    }

    private fun loadAlbums() {
        CoroutineScope(Dispatchers.IO).launch {
            val albums = albumDao.getAllAlbums()
            withContext(Dispatchers.Main) {
                adapter.submitList(albums)
            }
        }
    }
}
