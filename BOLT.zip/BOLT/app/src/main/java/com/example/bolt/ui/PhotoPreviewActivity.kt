package com.example.bolt.ui

import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.bolt.R


class PhotoPreviewActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photo_preview)

        val photoUri = intent.getParcelableExtra<Uri>("photoUri")
        val imageView = findViewById<ImageView>(R.id.photo_image_view)
        imageView.setImageURI(photoUri)
    }
}
