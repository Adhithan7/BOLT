package com.example.bolt.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.bolt.data.model.Photo

@Dao
interface PhotoDao {
    @Insert
    suspend fun insert(photo: Photo)

    @Query("SELECT * FROM photos WHERE albumId = :albumId")
    suspend fun getPhotos(albumId: Int): List<Photo>
}
